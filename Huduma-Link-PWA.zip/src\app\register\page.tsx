import OnboardingForm from "@/components/onboarding-form";

export default function RegisterPage() {
  return <OnboardingForm />;
}
