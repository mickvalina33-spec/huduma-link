const rules = [
  {
    title: "Jukwaa la kuaminika",
    text: "Huduma Link ni soko la huduma lililothibitishwa. Watoa huduma huchapishwa tu baada ya uthibitisho wa NIDA na nyaraka zao kuthibitishwa na wasimamizi.",
  },
  {
    title: "Mawasiliano ndani ya mfumo",
    text: "Mawasiliano, majadiliano ya bei na booking zote hufanyika ndani ya mfumo. Ni marufuku kutumia mfumo kwa kubadilishana namba za simu au kuelekeza wateja nje ya mfumo ili kuepuka kanuni hizi.",
  },
  {
    title: "Malipo nje ya mfumo na kamisheni ya 5%",
    text: "Malipo ya huduma hufanyika moja kwa moja kati ya mteja na mtoa huduma, nje ya mfumo. Mtoa huduma hulipa jukwaa kamisheni ya 5% ya thamani ya huduma iliyokamilika. Kila huduma iliyokamilika inapaswa kurekodiwa.",
  },
  {
    title: "Mwenendo uliopigwa marufuku",
    text: "Ulaghai, taarifa za uongo za utambulisho au NIDA, nyaraka za kughushi, kujivika sifa za kitaaluma zisizo zako, vitisho, unyanyasaji, maoni ya uongo, kughairi booking kwa udanganyifu, huduma haramu, na matumizi mabaya ya taarifa za mtumiaji haviruhusiwi.",
  },
  {
    title: "Faragha ya taarifa za NIDA",
    text: "Namba ya NIDA na picha za kitambulisho huhifadhiwa kwa faragha, hazionyeshwi hadharani, na hufikiwa na wasimamizi walioidhinishwa pekee kwa madhumuni ya uthibitisho na uzingatiaji wa sheria za ulinzi wa taarifa.",
  },
  {
    title: "Hatua za kinidhamu na rufaa",
    text: "Msimamizi anaweza kutoa onyo, kupunguza uwezo wa akaunti, kusimamisha au kuondoa akaunti, na kukataa au kusimamisha uthibitisho. Sababu hurekodiwa, na mtumiaji anaweza kuwasilisha rufaa kwa wasimamizi.",
  },
];

export default function RulesPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-5xl px-4 py-8 md:px-6 md:py-12">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Kanuni</p>
        <h1 className="mt-3 text-3xl font-bold tracking-tight text-white md:text-4xl">Kanuni na masharti ya matumizi</h1>
        <p className="mt-4 text-base leading-7 text-slate-300">Huduma Link ipo kuwapa wateja na watoa huduma mazingira salama, ya kuaminika na yenye kumbukumbu nzuri. Kutumia mfumo kunamaanisha kukubali kanuni hizi.</p>
      </header>

      <section className="mt-8 divide-y divide-slate-200 rounded-[24px] border border-slate-200 bg-white px-5 shadow-sm md:px-7">
        {rules.map((rule, index) => (
          <article key={rule.title} className="grid gap-3 py-5 md:grid-cols-[48px_1fr] md:gap-5 md:py-6">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#e8f3ec] text-sm font-bold text-[#0f5132]">0{index + 1}</span>
            <div>
              <h2 className="text-lg font-semibold text-slate-900">{rule.title}</h2>
              <p className="mt-2 text-sm leading-7 text-slate-600">{rule.text}</p>
            </div>
          </article>
        ))}
      </section>
    </main>
  );
}