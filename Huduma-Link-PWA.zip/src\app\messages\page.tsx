import { messageThreads } from "@/data/marketplace";

export default function MessagesPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-7">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Mawasiliano ndani ya mfumo</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Ujumbe</h1>
        </div>

        <div className="grid gap-6 lg:grid-cols-[0.9fr_1.1fr]">
          <aside className="rounded-[24px] border border-slate-200 bg-white p-3 shadow-sm">
            {messageThreads.map((thread) => (
              <button
                key={thread.id}
                className="mb-2 flex w-full items-start justify-between gap-3 rounded-2xl border border-transparent bg-slate-50 p-4 text-left transition hover:border-[#c7dfcf] hover:bg-[#f3f8f4]"
              >
                <div>
                  <p className="font-semibold text-slate-900">{thread.participant}</p>
                  <p className="mt-1 text-sm leading-5 text-slate-600">{thread.preview}</p>
                </div>
                <span className="shrink-0 text-xs text-slate-500">{thread.time}</span>
              </button>
            ))}
          </aside>

          <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
            <div className="mb-5 border-b border-slate-200 pb-4">
              <h2 className="text-xl font-semibold text-slate-900">Mtoa huduma wa umeme</h2>
              <p className="text-sm text-slate-500">Mradi: Kurekebisha nyaya za jikoni</p>
            </div>

            <div className="space-y-4 rounded-2xl bg-[#f7f8f6] p-4">
              <div className="max-w-xs rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-4 py-3 text-sm leading-6 text-slate-700">
                Tunaweza kubadilisha bodi ya kubadili iliyoathirika na kufanya ukaguzi wa usalama kabla ya Ijumaa.
              </div>
              <div className="ml-auto max-w-xs rounded-2xl rounded-tr-sm bg-[#e5f1e9] px-4 py-3 text-sm leading-6 text-[#183e29]">
                Imekubaliwa. Tafadhali thibitisha bei iliyorekebishwa na orodha ya vifaa kabla ya kuagiza kazi.
              </div>
              <div className="max-w-xs rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-4 py-3 text-sm leading-6 text-slate-700">
                Kiasi cha kazi kimewekwa tayari na ni pamoja na ubadilishaji wa taa na nyaya za dharura.
              </div>
            </div>

            <div className="mt-5 flex gap-3">
              <input
                className="min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132]"
                placeholder="Andika ujumbe wako..."
              />
              <button className="rounded-xl bg-[#0f5132] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b3d27]">
                Tuma
              </button>
            </div>
          </section>
        </div>
    </main>
  );
}
