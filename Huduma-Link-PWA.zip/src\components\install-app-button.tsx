"use client";

import { useEffect, useState } from "react";

type InstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
};

export default function InstallAppButton() {
  const [installPrompt, setInstallPrompt] = useState<InstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    const handleInstallPrompt = (event: Event) => {
      event.preventDefault();
      setInstallPrompt(event as InstallPromptEvent);
    };
    const handleInstalled = () => setIsInstalled(true);

    window.addEventListener("beforeinstallprompt", handleInstallPrompt);
    window.addEventListener("appinstalled", handleInstalled);

    if (window.matchMedia("(display-mode: standalone)").matches) {
      setIsInstalled(true);
    }

    return () => {
      window.removeEventListener("beforeinstallprompt", handleInstallPrompt);
      window.removeEventListener("appinstalled", handleInstalled);
    };
  }, []);

  const installApp = async () => {
    if (!installPrompt) return;
    await installPrompt.prompt();
    const choice = await installPrompt.userChoice;
    if (choice.outcome === "accepted") setIsInstalled(true);
    setInstallPrompt(null);
  };

  if (isInstalled) {
    return <p className="rounded-xl border border-[#294238] bg-[#13211c] px-4 py-3 text-sm text-[#b7c2bd]">Huduma Link tayari ipo kwenye kifaa hiki.</p>;
  }

  if (installPrompt) {
    return (
      <button type="button" onClick={installApp} className="rounded-xl bg-[#32ad8b] px-5 py-3 text-sm font-semibold text-[#10251e] transition hover:bg-[#45bd9b]">
        Sakinisha programu
      </button>
    );
  }

  return <p className="rounded-xl border border-[#294238] bg-[#13211c] px-4 py-3 text-sm leading-6 text-[#b7c2bd]">Tumia menyu ya kivinjari kuchagua “Add to Home Screen” kwenye iPhone au “Install app” kwenye Android.</p>;
}