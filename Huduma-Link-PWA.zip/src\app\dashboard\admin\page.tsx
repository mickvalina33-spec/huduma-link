import { adminOverview } from "@/data/marketplace";

export default function AdminDashboardPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Dashibodi ya msimamizi</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Uendeshaji wa soko</h1>
        </div>

        <div className="grid gap-5 md:grid-cols-4">
          {adminOverview.map((item) => (
            <div key={item.label} className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-sm text-slate-500">{item.label}</p>
              <p className="mt-2 text-2xl font-bold text-slate-900">{item.value}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-2">
          <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Foleni ya uthibitishaji</h2>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-600">
              <li>• Watoa huduma 18 wanasubiri ukaguzi wa NIDA</li>
              <li>• Hati 6 zinahitaji maelezo ya ziada</li>
              <li>• Usajili wa watoa huduma 2 umewekwa chini ya ukaguzi wa kanuni</li>
              <li>• Leseni 4 za kitaalamu zinahitaji uthibitishaji wa hati</li>
            </ul>
          </section>

          <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Utekelezaji</h2>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-600">
              <li>• Kagua migogoro kwa kutumia ushahidi wa booking na historia ya mawasiliano.</li>
              <li>• Toa onyo, simamisha akaunti kwa muda, au iondoe pale kanuni zinapokiukwa.</li>
              <li>• Hifadhi kumbukumbu za ukaguzi kwa mabadiliko ya akaunti na uthibitishaji.</li>
              <li>• Fuatilia malipo ya kamisheni na taarifa za miamala zilizofichwa.</li>
            </ul>
          </section>
        </div>
    </main>
  );
}
