import Link from "next/link";
import { categories, providers } from "@/data/marketplace";

export default function Home() {
  return (
    <main className="mx-auto max-w-7xl px-4 pb-16 pt-[31px] md:px-6">
      <section className="bg-transparent px-0 py-6">
        <div className="grid gap-8 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[#29463a] bg-[#13251e] px-3 py-1 text-xs font-medium text-[#37ad8b]">
              <span className="inline-flex h-4 w-4 items-center justify-center rounded-full bg-[#18372b] text-[#37ad8b]">✓</span>
              Watoa huduma waliothibitishwa kwa NIDA
            </div>

            <h1 className="max-w-3xl font-serif text-4xl font-semibold leading-[1.12] text-white md:text-5xl">
              Pata mtaalamu wa kuaminika, karibu nawe
            </h1>

            <p className="mt-[18px] max-w-3xl text-base leading-[1.65] text-[#b7c2bd]">
              Huduma Link ni soko la huduma lililothibitishwa Tanzania. Tafuta fundi au mtaalamu, jadiliane bei ndani ya mfumo, hakiki booking na fuatilia kumbukumbu ya kazi yote.
            </p>

            <div className="mt-8 flex flex-col gap-2 rounded-[20px] border border-[#294238] bg-transparent p-3 pt-2 md:flex-row md:items-center">
              <div className="flex flex-1 items-center gap-3 rounded-xl bg-transparent px-3 py-2">
                <span className="text-lg text-slate-400">⌕</span>
                <input
                  aria-label="Unaitaji huduma gani"
                  placeholder="Unaitaji huduma gani?"
                  className="w-full bg-transparent text-sm text-white placeholder:text-slate-400 outline-none"
                />
              </div>

              <div className="grid gap-2 md:grid-cols-2 xl:grid-cols-3">
                <select className="rounded-xl bg-transparent px-3 py-2.5 text-sm text-slate-200 outline-none">
                  <option>Makundi yote</option>
                  <option>Umeme</option>
                  <option>Usafi</option>
                  <option>Ujenzi</option>
                </select>
                <select className="rounded-xl bg-transparent px-3 py-2.5 text-sm text-slate-200 outline-none">
                  <option>Mikoa yote</option>
                  <option>Dar es Salaam</option>
                  <option>Arusha</option>
                  <option>Dodoma</option>
                </select>
                <button className="rounded-xl bg-[#32ad8b] px-5 py-2.5 text-sm font-semibold text-[#10251e] transition hover:bg-[#45bd9b]">
                  Tafuta
                </button>
              </div>
            </div>

            <div className="mt-6 flex flex-wrap gap-5 text-sm text-[#b7c2bd]">
              <div className="flex items-center gap-2">
                <span className="text-lg">💬</span>
                <span>Mawasiliano ndani ya mfumo</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg">💸</span>
                <span>Malipo moja kwa moja kwa mtoa huduma</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-lg">⭐</span>
                <span>Maoni kutoka kwa booking halisi</span>
              </div>
            </div>
          </div>

          <div className="rounded-[28px] bg-[#f8faf7] p-3 shadow-[0_20px_60px_rgba(15,81,50,0.08)] ring-1 ring-slate-200/80">
            <div className="overflow-hidden rounded-[24px] bg-gradient-to-br from-[#ecf5ef] via-white to-[#edf4ff] p-4">
              <div className="rounded-[20px] bg-white p-4 shadow-sm ring-1 ring-slate-200">
                <div className="flex items-center gap-3">
                  <div className="h-12 w-12 rounded-2xl bg-[#0f5132]" />
                  <div>
                    <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Watoa huduma</p>
                    <p className="text-3xl font-bold text-slate-900">0</p>
                  </div>
                </div>
                <p className="mt-4 text-sm text-slate-500">waliothibitishwa na kupatikana leo</p>
                <div className="mt-4 rounded-2xl border border-dashed border-[#b7d9c7] bg-[#f6fbf8] p-4 text-center text-sm text-slate-600">
                  Bado hakuna watoa huduma waliothibitishwa. Wewe unaweza kuwa wa kwanza.
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Makundi ya huduma</p>
            <h2 className="mt-2 text-3xl font-bold text-white">Chagua kundi la huduma</h2>
          </div>
          <Link href="/watoa-huduma" className="text-sm font-medium text-[#0f5132] hover:text-[#0b3d27]">
            Watoa huduma wote →
          </Link>
        </div>

        <div className="grid gap-4 md:grid-cols-3 xl:grid-cols-6">
          {categories.map((category) => (
            <div key={category.name} className="rounded-[24px] border border-slate-200 bg-white p-4 shadow-sm">
              <div className={`mb-4 h-12 rounded-2xl bg-gradient-to-r ${category.accent}`} />
              <h3 className="text-base font-semibold text-slate-900">{category.name}</h3>
              <p className="mt-2 text-sm text-slate-500">{category.count}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="py-8">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Waliothibitishwa</p>
            <h2 className="mt-2 text-3xl font-bold text-white">Watoa huduma wanaopendekezwa</h2>
          </div>
          <Link href="/providers" className="text-sm font-medium text-[#0f5132] hover:text-[#0b3d27]">
            Ona wote →
          </Link>
        </div>

        <div className="rounded-[28px] border border-dashed border-[#bfdac7] bg-[#f8fbf8] p-8 text-center">
          <p className="text-xl font-semibold text-slate-900">Bado hakuna watoa huduma waliothibitishwa. Wewe unaweza kuwa wa kwanza.</p>
          <Link href="/register/provider" className="mt-5 inline-flex rounded-full bg-[#0f5132] px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#0b3d27]">
            Fungua akaunti
          </Link>
        </div>
      </section>

      <section className="py-12">
        <div className="mb-8 text-center">
          <p className="text-xs uppercase tracking-[0.28em] text-slate-400">Jinsi inavyofanya kazi</p>
          <h2 className="mt-2 text-3xl font-bold text-white">Safari ya mteja, hatua kwa hatua</h2>
        </div>

        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-4">
          {[
            { step: "01", title: "Tafuta na chagua", text: "Chuja watoa huduma kwa kundi, mkoa na ukadiriaji, kisha angalia wasifu wao." },
            { step: "02", title: "Wasiliana na jadiliane bei", text: "Tuma ombi na jadilianeni bei ndani ya mfumo — kila hatua inarekodiwa." },
            { step: "03", title: "Hakiki booking na pokea huduma", text: "Bei inayokubaliwa inarekodiwa kabla ya kuhakiki booking." },
            { step: "04", title: "Lipa, thibitisha na toa maoni", text: "Lipa mtoa huduma moja kwa moja, thibitisha kukamilika na toa maoni yako." },
          ].map((item) => (
            <div key={item.step} className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
              <p className="text-3xl font-black text-[#0f5132]">{item.step}</p>
              <h3 className="mt-4 text-xl font-bold text-slate-900">{item.title}</h3>
              <p className="mt-3 text-sm leading-7 text-slate-600">{item.text}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-[32px] bg-[#0f5132] p-8 text-white md:flex md:items-center md:justify-between">
          <div className="max-w-2xl">
            <h3 className="text-3xl font-bold tracking-tight">Wewe ni fundi au mtaalamu?</h3>
            <p className="mt-3 text-base leading-7 text-emerald-50/90">
              Wasilisha namba yako ya NIDA na nyaraka zako, upate uthibitisho, kisha anza kupokea maombi kutoka kwa wateja. Jukwaa huchukua kamisheni ya 5% tu ya huduma zilizokamilika.
            </p>
          </div>

          <div className="mt-6 flex flex-wrap gap-3 md:mt-0">
            <Link href="/register/provider" className="rounded-full bg-white px-5 py-3 text-sm font-semibold text-[#0f5132] shadow-sm transition hover:bg-emerald-50">
              Fungua akaunti
            </Link>
            <Link href="/register" className="rounded-full border border-white/30 px-5 py-3 text-sm font-semibold text-white transition hover:bg-white/10">
              Soma kanuni
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
