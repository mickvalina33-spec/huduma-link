import { customerBookings } from "@/data/marketplace";

function formatTzs(value: number) {
  return new Intl.NumberFormat("en-TZ", {
    style: "currency",
    currency: "TZS",
    maximumFractionDigits: 0,
  }).format(value);
}

export default function BookingsPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-8 flex items-center justify-between gap-4">
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Mifumo ya maagizo</p>
            <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Maagizo yangu</h1>
          </div>
          <button className="rounded-full bg-[#0f5132] px-4 py-2 text-sm font-semibold text-white transition hover:bg-[#0b3d27]">
            Agiza huduma mpya
          </button>
        </div>

        <div className="grid gap-5 lg:grid-cols-3">
          {customerBookings.map((booking) => (
            <div key={booking.id} className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">{booking.id}</span>
                <span className="rounded-full bg-[#e8f3ec] px-2.5 py-1 text-xs font-medium text-[#0f5132]">{booking.status}</span>
              </div>
              <h2 className="mt-4 text-xl font-semibold text-slate-900">{booking.service}</h2>
              <p className="mt-2 text-sm text-slate-600">Mtoa huduma: {booking.provider}</p>
              <div className="mt-5 rounded-2xl bg-[#f3f8f4] p-4">
                <p className="text-xs font-medium uppercase tracking-[0.18em] text-slate-500">Bei iliyokubaliwa</p>
                <p className="mt-2 text-2xl font-bold text-[#0f5132]">{formatTzs(booking.price)}</p>
              </div>
              <div className="mt-4 space-y-2 text-sm text-slate-600">
                <p>• Mawasiliano ndani ya app yamehifadhiwa</p>
                <p>• Agizo limeandikwa na historia ya hali</p>
                <p>• Komisheni itahesabiwa baada ya kukamilika</p>
              </div>
            </div>
          ))}
        </div>
    </main>
  );
}
