import Link from "next/link";
import InstallAppButton from "@/components/install-app-button";

export default function InstallPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-5xl px-4 py-10 md:px-6 md:py-14">
      <div className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#32ad8b]">Huduma Link kwa simu</p>
        <h1 className="mt-3 font-serif text-3xl font-semibold text-white md:text-4xl">Sakinisha programu</h1>
        <p className="mt-4 text-base leading-7 text-[#b7c2bd]">Ongeza Huduma Link kwenye kifaa chako ili kuifungua moja kwa moja kutoka kwenye skrini ya mwanzo.</p>
        <div className="mt-6">
          <InstallAppButton />
        </div>
      </div>

      <div className="mt-9 grid gap-4 md:grid-cols-2">
        <section className="rounded-[22px] border border-white/10 bg-[#13211c] p-5">
          <h2 className="text-lg font-semibold text-white">Android</h2>
          <ol className="mt-3 list-inside list-decimal space-y-2 text-sm leading-6 text-slate-300">
            <li>Fungua ukurasa huu kwenye Chrome.</li>
            <li>Bonyeza “Sakinisha programu” au fungua menyu ya Chrome na uchague “Install app”.</li>
            <li>Thibitisha kusakinisha ili kuongeza ikoni kwenye skrini ya mwanzo.</li>
          </ol>
        </section>
        <section className="rounded-[22px] border border-white/10 bg-[#13211c] p-5">
          <h2 className="text-lg font-semibold text-white">iPhone na iPad</h2>
          <ol className="mt-3 list-inside list-decimal space-y-2 text-sm leading-6 text-slate-300">
            <li>Fungua ukurasa huu kwenye Safari.</li>
            <li>Bonyeza kitufe cha Share, kisha uchague “Add to Home Screen”.</li>
            <li>Bonyeza “Add” ili kuhifadhi Huduma Link kwenye skrini ya mwanzo.</li>
          </ol>
        </section>
      </div>

      <Link href="/" className="mt-8 inline-flex text-sm font-medium text-[#32ad8b] hover:text-[#45bd9b]">Rudi Huduma Link</Link>
    </main>
  );
}