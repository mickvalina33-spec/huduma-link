"use client";

import { FormEvent, useState } from "react";

type AccountRole = "customer" | "provider";

const regions = ["Dar es Salaam", "Arusha", "Dodoma", "Mwanza", "Morogoro", "Mbeya", "Tanga", "Zanzibar"];

const inputClassName = "w-full rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10";

export default function OnboardingForm() {
  const [role, setRole] = useState<AccountRole>("customer");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  const changeRole = (nextRole: AccountRole) => {
    setRole(nextRole);
    setSubmitted(false);
  };

  return (
    <main className="mx-auto max-w-5xl px-4 py-8 md:px-6 md:py-12">
      <header className="max-w-3xl">
        <p className="text-xs font-semibold uppercase tracking-[0.22em] text-[#38ad89]">Fungua akaunti</p>
        <h1 className="mt-3 text-3xl font-bold text-white md:text-4xl">Karibu Huduma Link</h1>
        <p className="mt-4 text-base leading-7 text-slate-300">
          Chagua aina ya akaunti. Wateja huomba huduma na kufuatilia kazi; watoa huduma hupitia uthibitisho wa NIDA kabla ya kuorodheshwa hadharani.
        </p>
      </header>

      <div className="mt-7 grid gap-3 sm:grid-cols-2">
        <button
          type="button"
          aria-pressed={role === "customer"}
          onClick={() => changeRole("customer")}
          className={`rounded-2xl border p-4 text-left transition ${role === "customer" ? "border-[#42b893] bg-[#16372b]" : "border-white/10 bg-[#13211c] hover:border-white/25"}`}
        >
          <span className="text-base font-semibold text-white">Mimi ni mteja</span>
          <span className="mt-1 block text-sm text-slate-300">Omba huduma, jadiliane bei na toa maoni.</span>
        </button>
        <button
          type="button"
          aria-pressed={role === "provider"}
          onClick={() => changeRole("provider")}
          className={`rounded-2xl border p-4 text-left transition ${role === "provider" ? "border-[#42b893] bg-[#16372b]" : "border-white/10 bg-[#13211c] hover:border-white/25"}`}
        >
          <span className="text-base font-semibold text-white">Mimi ni mtoa huduma</span>
          <span className="mt-1 block text-sm text-slate-300">Wasilisha NIDA yako na uanze kupokea maombi.</span>
        </button>
      </div>

      {submitted ? (
        <div className="mt-5 rounded-[24px] border border-[#c7dfcf] bg-white p-6 text-slate-900">
          <h2 className="text-lg font-semibold">{role === "customer" ? "Usajili umepokelewa." : "Maombi yako yamepokelewa."}</h2>
          <p className="mt-2 text-sm leading-6 text-slate-600">{role === "customer" ? "Taarifa zako zimepokelewa. Timu yetu itawasiliana nawe kuhusu hatua zinazofuata." : "Timu ya uthibitishaji itakagua taarifa za biashara na NIDA kabla ya akaunti yako kuorodheshwa."}</p>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="mt-5 rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm md:p-7">
          <div className="grid gap-4 md:grid-cols-2">
            {role === "customer" ? (
              <>
                <label className="space-y-2">
                  <span className="text-sm font-medium text-slate-700">Jina kamili *</span>
                  <input required className={inputClassName} placeholder="Mfano: Asha Mwinyi" />
                </label>
                <label className="space-y-2">
                  <span className="text-sm font-medium text-slate-700">Barua pepe</span>
                  <input type="email" className={inputClassName} placeholder="jina@barua.com" />
                </label>
              </>
            ) : (
              <>
                <label className="space-y-2">
                  <span className="text-sm font-medium text-slate-700">Jina la biashara *</span>
                  <input required className={inputClassName} placeholder="Mfano: Huduma za Mabomba" />
                </label>
                <label className="space-y-2">
                  <span className="text-sm font-medium text-slate-700">Namba ya NIDA *</span>
                  <input required inputMode="numeric" className={inputClassName} placeholder="Ingiza namba yako ya NIDA" />
                </label>
              </>
            )}

            <label className="space-y-2">
              <span className="text-sm font-medium text-slate-700">Mkoa *</span>
              <select required defaultValue="" className={inputClassName}>
                <option value="" disabled>Chagua mkoa</option>
                {regions.map((region) => <option key={region}>{region}</option>)}
              </select>
            </label>
            <label className="space-y-2">
              <span className="text-sm font-medium text-slate-700">Wilaya / kata</span>
              <input className={inputClassName} placeholder="Mfano: Kinondoni" />
            </label>

            {role === "provider" && (
              <label className="space-y-2 md:col-span-2">
                <span className="text-sm font-medium text-slate-700">Aina ya huduma *</span>
                <select required defaultValue="" className={inputClassName}>
                  <option value="" disabled>Chagua kundi la huduma</option>
                  <option>Ujenzi wa Nyumba</option>
                  <option>Umeme</option>
                  <option>Usafi</option>
                  <option>Mifumo ya Majitaka</option>
                  <option>Teknolojia na Dijitali</option>
                </select>
              </label>
            )}
          </div>

          <p className="mt-4 text-xs leading-5 text-slate-500">
            {role === "customer" ? "Namba ya simu hutumika kwa uthibitisho wa akaunti, lakini haionyeshwi kwa watoa huduma." : "Taarifa za NIDA ni za faragha na huonwa na wasimamizi walioidhinishwa pekee."} Mawasiliano yote hufanyika ndani ya mfumo.
          </p>
          <button type="submit" className="mt-5 rounded-full bg-[#0f5132] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b3d27]">
            {role === "customer" ? "Fungua akaunti ya mteja" : "Tuma maombi ya mtoa huduma"}
          </button>
        </form>
      )}

      <p className="mt-5 text-center text-sm text-slate-400">Taarifa zako huhifadhiwa kwa usiri. Namba za simu hazionyeshwi kwa watumiaji wengine.</p>
    </main>
  );
}