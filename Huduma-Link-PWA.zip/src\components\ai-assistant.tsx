"use client";

import { useEffect, useMemo, useRef, useState } from "react";

const quickReplies = [
  "Nahitaji kukumbushwa kuhusu hatua ya kuagiza huduma",
  "Ninaweza kupata mtoa huduma wa umeme?",
  "Ningependa kujua kuhusu komisheni ya 5%",
  "Naomba msaada wa kupendekeza huduma ya usafi",
];

function buildAiReply(input: string) {
  const normalized = input.toLowerCase();

  if (normalized.includes("bei") || normalized.includes("price") || normalized.includes("gharama")) {
    return "Kiasi cha huduma kinaweza kujadiliwa ndani ya app kabla ya kuthibitisha agizo. Ndani ya mazungumzo, mtoa huduma anakupa bei na unaweza kukubaliana kwa njia ya ndani ya mfumo.";
  }

  if (normalized.includes("umeme") || normalized.includes("electrical") || normalized.includes("nyaya")) {
    return "Unaweza kuchagua mtoa huduma wa umeme kutoka sehemu ya 'Watoa huduma' na kutuma ombi la huduma. Baada ya kukubaliana, mtoa huduma atakupa bei na ratiba inayokufaa.";
  }

  if (normalized.includes("usafi") || normalized.includes("clean") || normalized.includes("safisha")) {
    return "Kwa huduma ya usafi, tunaweza kukutambulisha mtoa huduma wa usafi karibu nawe. Tafadhali eleza eneo lako, ukubwa wa eneo na siku unazotaka huduma.";
  }

  if (normalized.includes("komisheni") || normalized.includes("5%") || normalized.includes("commission")) {
    return "Kwa muundo huu, mteja hulipa mtoa huduma moja kwa moja nje ya app. Mtoa huduma ndiye anawajibika kulipa komisheni ya 5% ya thamani ya huduma iliyokamilika kupitia mfumo wa app.";
  }

  if (normalized.includes("agizo") || normalized.includes("booking") || normalized.includes("kuagiza")) {
    return "Kuhusu agizo, unaweza kutuma ombi la huduma, kujadili gharama, kuthibitisha tarehe na mahali, na kisha ukakubali maelezo kabla ya huduma kuanza.";
  }

  if (normalized.includes("salama") || normalized.includes("nida") || normalized.includes("safety")) {
    return "Tumeweka ukaguzi wa NIDA na uthibitishaji wa mtoa huduma kabla ya huduma kuonekana hadharani. Maelezo ya NIDA hayafichwi kwa umma na yanatumika kwa madhumuni ya usalama pekee.";
  }

  return "Ninaweza kukusaidia kuhusu kutafuta huduma, kujadili bei, kukubali agizo, au kuelewa kanuni za platformi. Unaweza kuniuliza mfano: 'Nahitaji mtoa huduma wa bomba' au 'Ninaelewa jinsi komisheni inavyokokotwa?'";
}

export default function AIAssistant() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    const handleOpenAssistant = () => setIsOpen(true);
    window.addEventListener("ai-assistant-open", handleOpenAssistant);

    return () => {
      window.removeEventListener("ai-assistant-open", handleOpenAssistant);
    };
  }, []);

  const [messages, setMessages] = useState([
    {
      id: "welcome",
      role: "assistant",
      text: "Habari! Mimi ni msaidizi wako wa AI wa huduma. Naweza kukusaidia kupata huduma, kuelewa gharama, au kuangalia hatua za agizo kwa Kiswahili.",
    },
  ]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const suggestions = useMemo(() => quickReplies, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages]);

  const sendMessage = (value: string) => {
    const text = value.trim();
    if (!text) return;

    setMessages((current) => [
      ...current,
      { id: `${Date.now()}-user`, role: "user", text },
      { id: `${Date.now()}-assistant`, role: "assistant", text: buildAiReply(text) },
    ]);
    setInput("");
  };

  if (!isOpen) return null;

  return (
    <div className="fixed bottom-20 right-4 z-30 w-[min(360px,calc(100vw-2rem))] md:bottom-5 md:right-5">
        <div className="flex max-h-[calc(100dvh-6rem)] flex-col overflow-hidden rounded-[24px] border border-slate-200 bg-white shadow-2xl shadow-slate-900/20 md:max-h-[calc(100dvh-2.5rem)]">
          <div className="flex shrink-0 items-center justify-between bg-[#0f5132] px-4 py-3 text-white">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.18em]">Huduma kwa wateja</p>
              <p className="text-sm font-semibold">Msaidizi wa huduma</p>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              className="rounded-full px-3 py-2 text-xs font-semibold text-white/90 hover:bg-white/10"
            >
              Funga
            </button>
          </div>

          <div className="shrink-0 border-b border-slate-200 bg-white px-3 py-2">
            <div className="flex gap-2 overflow-x-auto pb-1">
              {suggestions.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => sendMessage(item)}
                  className="shrink-0 rounded-full border border-[#c7dfcf] bg-[#f3f8f4] px-2.5 py-1.5 text-[10px] font-medium text-[#0f5132] transition hover:bg-[#e8f3ec]"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <div className="min-h-0 flex-1 space-y-3 overflow-y-auto bg-[#f7f8f6] p-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={message.role === "assistant" ? "max-w-[90%] rounded-2xl rounded-tl-sm border border-slate-200 bg-white px-3 py-2 text-sm leading-6 text-slate-700" : "ml-auto max-w-[85%] rounded-2xl rounded-tr-sm bg-[#e5f1e9] px-3 py-2 text-sm leading-6 text-[#183e29]"}
              >
                {message.text}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>

          <div className="shrink-0 border-t border-slate-200 bg-white p-3">
            <div className="flex gap-2">
              <input
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    sendMessage(input);
                  }
                }}
                placeholder="Uliza swali lako..."
                className="min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-3 py-2.5 text-sm text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132]"
              />
              <button
                type="button"
                onClick={() => sendMessage(input)}
                className="rounded-xl bg-[#0f5132] px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-[#0b3d27]"
              >
                Tuma
              </button>
            </div>
          </div>
        </div>
    </div>
  );
}
