import { providerTransactions } from "@/data/marketplace";

function formatTzs(value: number) {
  return new Intl.NumberFormat("en-TZ", {
    style: "currency",
    currency: "TZS",
    maximumFractionDigits: 0,
  }).format(value);
}

export default function ProviderDashboardPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Dashibodi ya mtoa huduma</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Mtoa huduma</h1>
        </div>

        <div className="grid gap-5 md:grid-cols-4">
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Jumla ya thamani</p>
            <p className="mt-2 text-2xl font-bold text-slate-900">TZS 311M</p>
          </div>
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Komisheni iliyotokana</p>
            <p className="mt-2 text-2xl font-bold text-slate-900">TZS 15.5M</p>
          </div>
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Komisheni iliyolipwa</p>
            <p className="mt-2 text-2xl font-bold text-slate-900">TZS 9.4M</p>
          </div>
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Inayosubiri</p>
            <p className="mt-2 text-2xl font-bold text-[#0f5132]">TZS 6.1M</p>
          </div>
        </div>

        <div className="mt-8 rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
          <h2 className="text-xl font-semibold text-slate-900">Kumbukumbu ya komisheni</h2>
          <div className="mt-4 overflow-x-auto rounded-2xl border border-slate-200">
            <table className="min-w-full text-left text-sm text-slate-700">
              <thead className="bg-[#f3f8f4] text-xs uppercase tracking-[0.16em] text-slate-600">
                <tr>
                  <th className="px-4 py-3">Agizo</th>
                  <th className="px-4 py-3">Thamani</th>
                  <th className="px-4 py-3">Iliyotokana</th>
                  <th className="px-4 py-3">Iliyolipwa</th>
                  <th className="px-4 py-3">Inayosubiri</th>
                </tr>
              </thead>
              <tbody>
                {providerTransactions.map((transaction) => (
                  <tr key={transaction.id} className="border-t border-slate-200">
                    <td className="px-4 py-3">{transaction.booking}</td>
                    <td className="px-4 py-3">{formatTzs(transaction.value)}</td>
                    <td className="px-4 py-3">{formatTzs(transaction.commissionGenerated)}</td>
                    <td className="px-4 py-3">{formatTzs(transaction.commissionPaid)}</td>
                    <td className="px-4 py-3 font-medium text-[#0f5132]">{formatTzs(transaction.outstanding)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
    </main>
  );
}
