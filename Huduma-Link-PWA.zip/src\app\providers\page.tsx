"use client";

import Link from "next/link";
import { useState } from "react";
import { categories, providers } from "@/data/marketplace";

function formatTzs(value: number) {
  return new Intl.NumberFormat("en-TZ", {
    style: "currency",
    currency: "TZS",
    maximumFractionDigits: 0,
  }).format(value);
}

export default function ProvidersPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");
  const [location, setLocation] = useState("");

  const filteredProviders = providers.filter((provider) => {
    const matchesSearch = `${provider.name} ${provider.category} ${provider.description} ${provider.specialties.join(" ")}`
      .toLowerCase()
      .includes(search.toLowerCase());
    const matchesCategory = !category || provider.category === category;
    const matchesLocation = !location || provider.location.includes(location) || provider.serviceArea.includes(location);
    return matchesSearch && matchesCategory && matchesLocation;
  });

  const clearFilters = () => {
    setSearch("");
    setCategory("");
    setLocation("");
  };

  return (
    <main className="mx-auto min-h-[60vh] max-w-7xl px-4 py-8 md:px-6 md:py-12">
      <section>
        <div className="max-w-4xl">
          <p className="text-xs font-semibold uppercase tracking-[0.2em] text-[#d69243]">Watoa huduma waliothibitishwa</p>
          <h1 className="mt-3 font-serif text-3xl font-semibold text-white md:text-4xl">Tafuta mtaalamu anayefaa</h1>
          <p className="mt-4 text-base leading-7 text-[#b7c2bd]">
            Kila mtoa huduma aliyeorodheshwa hapa amepitia uthibitisho wa NIDA na nyaraka zake. Wasiliana naye, jadiliane bei na hakikisha booking yako ndani ya mfumo.
          </p>
        </div>

        <div className="mt-7 rounded-[22px] border border-[#294238] bg-[#13211c] p-4 md:p-5">
          <div className="grid gap-3">
            <label className="flex items-center gap-3 rounded-2xl border border-[#294238] bg-transparent px-4 py-3">
              <span aria-hidden="true" className="text-lg text-slate-400">⌕</span>
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                className="w-full bg-transparent text-sm text-white outline-none placeholder:text-slate-400"
                placeholder="Tafuta huduma, mfano: mabomba, kushona nguo..."
              />
            </label>
            <select
              aria-label="Chagua kundi la huduma"
              value={category}
              onChange={(event) => setCategory(event.target.value)}
              className="rounded-2xl border border-[#294238] bg-transparent px-4 py-3 text-sm text-slate-200 outline-none focus:border-[#32ad8b]"
            >
              <option value="">Makundi yote</option>
              {categories.map((item) => <option key={item.name} value={item.name}>{item.name}</option>)}
            </select>
            <select
              aria-label="Chagua mkoa"
              value={location}
              onChange={(event) => setLocation(event.target.value)}
              className="rounded-2xl border border-[#294238] bg-transparent px-4 py-3 text-sm text-slate-200 outline-none focus:border-[#32ad8b]"
            >
              <option value="">Mikoa yote</option>
              <option value="Dar es Salaam">Dar es Salaam</option>
              <option value="Arusha">Arusha</option>
              <option value="Dodoma">Dodoma</option>
              <option value="Mwanza">Mwanza</option>
            </select>
          </div>
        </div>

        <div className="flex flex-col gap-3 border-b border-white/10 py-5 text-sm text-slate-300 sm:flex-row sm:items-center sm:justify-between">
          <p><span className="font-semibold text-white">{filteredProviders.length}</span> watoa huduma wamepatikana</p>
          {(search || category || location) && (
            <button type="button" onClick={clearFilters} className="self-start font-medium text-[#32ad8b] hover:underline sm:self-auto">
              Safisha vichujio
            </button>
          )}
        </div>
      </section>

      {filteredProviders.length === 0 ? (
        <section className="py-14 text-center">
          <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-[#16372b] text-2xl text-[#32ad8b]">⌕</div>
          <h2 className="mt-5 text-xl font-semibold text-white">Hakuna mtoa huduma anayelingana na utafutaji wako</h2>
          <p className="mt-2 text-sm text-slate-300">Jaribu kubadilisha kundi la huduma au mkoa.</p>
          <button type="button" onClick={clearFilters} className="mt-5 rounded-full border border-white/20 bg-transparent px-4 py-2 text-sm font-medium text-slate-200 transition hover:border-[#32ad8b] hover:text-[#32ad8b]">
            Safisha vichujio
          </button>
          <p className="mt-8 text-sm text-slate-300">Mtoa huduma umeidhinishwa? <Link href="/register/provider" className="font-semibold text-emerald-300 hover:underline">Fungua akaunti</Link></p>
        </section>
      ) : (
        <section className="grid gap-5 py-8 md:grid-cols-2 xl:grid-cols-3">
          {filteredProviders.map((provider) => (
              <Link
                key={provider.id}
                href={`/providers/${provider.id}`}
                className="group overflow-hidden rounded-[24px] border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-md"
              >
                <div className="h-40 bg-[#edf4ef] p-5">
                  <div className="flex items-start justify-between">
                    <div className="rounded-full bg-white px-3 py-1 text-xs font-semibold text-[#0f5132]">
                      {provider.verification}
                    </div>
                    <span className="rounded-full bg-white px-2 py-1 text-xs text-slate-700">★ {provider.rating}</span>
                  </div>
                  <div className="mt-10">
                    <p className="text-xs uppercase tracking-[0.2em] text-slate-500">{provider.category}</p>
                    <h2 className="mt-2 text-2xl font-semibold text-slate-900">{provider.name}</h2>
                  </div>
                </div>

                <div className="space-y-4 p-5">
                  <div className="flex items-center justify-between text-sm text-slate-600">
                    <span>{provider.location}</span>
                    <span>{provider.reviews} maoni</span>
                  </div>

                  <p className="text-sm leading-6 text-slate-600">{provider.description}</p>

                  <div className="flex flex-wrap gap-2">
                    {provider.specialties.slice(0, 3).map((specialty) => (
                      <span key={specialty} className="rounded-full bg-slate-100 px-2.5 py-1 text-xs text-slate-700">
                        {specialty}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between border-t border-slate-200 pt-4">
                    <div>
                      <p className="text-xs uppercase tracking-[0.2em] text-slate-500">Kutoka</p>
                      <p className="mt-1 text-xl font-semibold text-[#0f5132]">{formatTzs(provider.priceFrom)}</p>
                    </div>
                    <span className="rounded-full border border-[#c9dfd0] px-3 py-2 text-xs font-medium text-[#0f5132]">
                      {provider.delivered} zilizomalizika
                    </span>
                  </div>
                </div>
              </Link>
          ))}
        </section>
      )}
    </main>
  );
}
