"use client";

import { FormEvent, useState } from "react";

export default function ProviderRegistrationPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-8 md:px-6 md:py-12">
      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm md:p-8">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Fungua akaunti / Mtoa huduma</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-900">Taarifa za biashara yako</h1>
          <p className="mt-3 text-sm leading-6 text-slate-600">Wasilisha taarifa zako kwa ajili ya uhakiki. Maelezo ya NIDA hayaonyeshwi hadharani na hukaguliwa na wasimamizi walioidhinishwa pekee.</p>
        </div>

        {submitted ? (
          <div className="rounded-2xl border border-[#c7dfcf] bg-[#f3faf5] p-5 text-slate-800">
            <p className="text-lg font-semibold">Maombi yako yamepokelewa.</p>
            <p className="mt-2 text-sm text-slate-600">Timu ya uthibitishaji itakagua NIDA, taarifa za biashara, na eneo la huduma kabla ya kukubali kuonekana kwenye soko.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid gap-5 md:grid-cols-2">
            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Jina la biashara / kampuni</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Mfano: Huduma za Mabomba" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Jina la mwanzilishi</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Mfano: Daniel Mwangoka" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Namba ya simu</span>
              <input type="tel" required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="+255 712 345 678" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Namba ya NIDA</span>
              <input required inputMode="numeric" className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Ingiza namba yako ya NIDA" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Aina ya huduma</span>
              <select required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-700 outline-none focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10">
                <option value="">Chagua huduma</option>
                <option>Umeme</option>
                <option>Usafi</option>
                <option>Mifumo ya maji</option>
                <option>Ujenzi wa nyumba</option>
                <option>Teknolojia na IT</option>
              </select>
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Eneo la huduma</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Dar es Salaam, Arusha, Dodoma" />
            </label>

            <label className="space-y-2 md:col-span-2">
              <span className="text-sm font-medium text-slate-700">Kifupi cha huduma / utaalamu</span>
              <textarea rows={3} required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Eleza huduma zako, uzoefu, na vipengele vinavyotolewa kwa wateja." />
            </label>

            <div className="flex flex-col gap-4 border-t border-slate-200 pt-5 md:col-span-2 md:flex-row md:items-center md:justify-between">
              <p className="max-w-md text-xs leading-5 text-slate-500">Orodha yako itaonekana baada ya timu kukagua taarifa kamili na kuthibitisha NIDA.</p>
              <button type="submit" className="rounded-full bg-[#0f5132] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b3d27]">
                Wasilisha usajili
              </button>
            </div>
          </form>
        )}
      </div>
    </main>
  );
}
