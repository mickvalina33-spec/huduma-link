# Huduma Link Mobile App Package

This package contains the Huduma Link web app configured as an installable Progressive Web App (PWA). It is a source/deployment package, not a native APK or IPA binary.

## Build and run

Requirements: Node.js 20.9 or newer.

```bash
npm ci
npm run build
npm run start
```

For mobile installation, deploy the app to a public HTTPS address. The service worker and home-screen installation require a secure origin.

## Install on Android

Open the deployed site in Chrome, visit `/install`, and choose **Sakinisha programu**. If the install prompt is unavailable, use Chrome's menu and choose **Install app**.

## Install on iPhone or iPad

Open the deployed site in Safari, visit `/install`, tap **Share**, choose **Add to Home Screen**, then tap **Add**.

## Native binaries

Building an APK requires Java and the Android SDK. Building and signing an IPA requires macOS, Xcode, and Apple signing credentials. Those native build tools are not included in this package.