"use client";

import Link from "next/link";
import { useState } from "react";

const options = [
  {
    label: "Msaidizi wa AI",
    action: "ai",
    description: "Msaidizi wa huduma kwa Kiswahili",
  },
  {
    label: "Jiandikisha kama mteja",
    action: "customer-register",
    description: "Unda akaunti ya huduma kwa mteja",
  },
  {
    label: "Jiandikisha kama mtoa huduma",
    action: "provider-register",
    description: "Wasilisha maelezo ya biashara yako",
  },
  {
    label: "Ujumbe wa mteja",
    action: "messages",
    description: "Fungua mawasiliano ya app",
  },
  {
    label: "Maagizo ya huduma",
    action: "bookings",
    description: "Fungua orodha ya maagizo",
  },
];

export default function CustomerServiceMenu() {
  const [isOpen, setIsOpen] = useState(false);

  const handleAction = (action: string) => {
    setIsOpen(false);

    if (action === "ai") {
      window.dispatchEvent(new CustomEvent("ai-assistant-open"));
      return;
    }

    if (action === "customer-register") {
      window.location.href = "/register/customer";
      return;
    }

    if (action === "provider-register") {
      window.location.href = "/register/provider";
      return;
    }

    if (action === "messages") {
      window.location.href = "/messages";
      return;
    }

    if (action === "bookings") {
      window.location.href = "/bookings";
    }
  };

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setIsOpen((current) => !current)}
        className="inline-flex min-h-11 items-center gap-2 rounded-2xl border border-white/15 bg-[#13211c] px-3 py-2 text-xs font-medium text-white transition hover:border-white/30 hover:bg-[#172720]"
      >
        <span>Chagua mtumiaji</span>
        <span aria-hidden="true" className="text-slate-400">⌄</span>
      </button>

      {isOpen ? (
        <div className="absolute right-0 z-50 mt-3 w-72 rounded-2xl border border-slate-200 bg-white p-2 shadow-xl shadow-slate-900/10">
          {options.map((option) => (
            <button
              key={option.action}
              type="button"
              onClick={() => handleAction(option.action)}
              className="flex w-full items-center justify-between rounded-xl px-3 py-3 text-left transition hover:bg-[#f3f8f4]"
            >
              <div>
                <div className="text-sm font-semibold text-slate-900">{option.label}</div>
                <div className="mt-1 text-xs text-slate-500">{option.description}</div>
              </div>
              <span className="text-lg text-[#0f5132]">→</span>
            </button>
          ))}

          <div className="mt-2 border-t border-slate-200 pt-2">
            <Link
              href="/watoa-huduma"
              className="flex w-full items-center justify-between rounded-xl px-3 py-2 text-sm text-slate-600 transition hover:bg-[#f3f8f4] hover:text-[#0f5132]"
            >
              <span>Tafuta mtoa huduma</span>
              <span>→</span>
            </Link>
          </div>
        </div>
      ) : null}
    </div>
  );
}
