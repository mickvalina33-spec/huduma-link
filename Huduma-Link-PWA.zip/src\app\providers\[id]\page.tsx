import Link from "next/link";
import { notFound } from "next/navigation";
import { providers } from "@/data/marketplace";

export function generateStaticParams() {
  if (providers.length === 0) {
    return [{ id: "placeholder" }];
  }

  return providers.map((provider) => ({ id: provider.id }));
}

function formatTzs(value: number) {
  return new Intl.NumberFormat("en-TZ", {
    style: "currency",
    currency: "TZS",
    maximumFractionDigits: 0,
  }).format(value);
}

export default async function ProviderDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const provider = providers.find((item) => item.id === id);

  if (!provider || id === "placeholder") {
    notFound();
  }

  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-6 flex items-center justify-between gap-4">
          <Link href="/watoa-huduma" className="text-sm font-medium text-slate-300 transition hover:text-white">
            ← Rudi kwenye watoa huduma
          </Link>
          <div className="rounded-full border border-[#c7dfcf] bg-[#f3f8f4] px-3 py-1 text-xs font-medium text-[#0f5132]">
            {provider.verification}
          </div>
        </div>

        <section className="overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm">
          <div className="grid gap-8 p-6 lg:grid-cols-[1.3fr_0.7fr] lg:p-8">
            <div>
              <div className="mb-5 flex items-center gap-3">
                <div className="h-16 w-16 rounded-2xl bg-[#e8f3ec]" />
                <div>
                  <p className="text-xs font-medium uppercase tracking-[0.2em] text-slate-500">{provider.category}</p>
                  <h1 className="mt-1 text-3xl font-bold text-slate-900">{provider.name}</h1>
                </div>
              </div>

              <p className="max-w-2xl text-base leading-7 text-slate-600">{provider.description}</p>

              <div className="mt-6 flex flex-wrap gap-3 text-sm text-slate-700">
                <span className="rounded-full bg-slate-100 px-3 py-1.5">★ {provider.rating} ukadiriaji</span>
                <span className="rounded-full bg-slate-100 px-3 py-1.5">{provider.reviews} maoni</span>
                <span className="rounded-full bg-slate-100 px-3 py-1.5">{provider.delivered} huduma zilizokamilika</span>
              </div>

              <div className="mt-8 grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Eneo</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{provider.location}</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Eneo la huduma</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{provider.serviceArea}</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Upatikanaji</p>
                  <p className="mt-2 text-lg font-semibold text-slate-900">{provider.availability}</p>
                </div>
                <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <p className="text-xs uppercase tracking-[0.18em] text-slate-500">Kutoka</p>
                  <p className="mt-2 text-lg font-semibold text-[#0f5132]">{formatTzs(provider.priceFrom)}</p>
                </div>
              </div>
            </div>

            <aside className="rounded-[24px] border border-[#d5e7da] bg-[#f5faf6] p-5">
              <div className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-[#0f5132]">Agizo</div>
              <div className="space-y-4">
                <div className="rounded-2xl bg-white p-4">
                  <p className="text-sm text-slate-500">Kiasi kinachokadiriwa</p>
                  <p className="mt-2 text-3xl font-bold text-slate-900">{formatTzs(provider.priceFrom)}</p>
                </div>
                <button className="w-full rounded-xl bg-[#0f5132] px-4 py-3 font-semibold text-white transition hover:bg-[#0b3d27]">
                  Omba huduma
                </button>
                <button className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 font-semibold text-slate-700 transition hover:border-[#0f5132] hover:text-[#0f5132]">
                  Tuma ujumbe
                </button>
                <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-4 text-sm leading-6 text-slate-600">
                  Namba za simu hazionekani hadharani. Mawasiliano yote hufanyika kupitia ujumbe ndani ya app na hatua za agizo.
                </div>
              </div>
            </aside>
          </div>
        </section>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1.15fr_0.85fr]">
          <section className="rounded-[24px] border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Uwezo</h2>
            <div className="mt-4 flex flex-wrap gap-2">
              {provider.specialties.map((specialty) => (
                <span key={specialty} className="rounded-full border border-[#c7dfcf] bg-[#f3f8f4] px-3 py-1.5 text-sm text-[#0f5132]">
                  {specialty}
                </span>
              ))}
            </div>

            <div className="mt-8">
              <h3 className="text-xl font-semibold text-slate-900">Kazi zilizofanywa</h3>
              <div className="mt-4 space-y-4">
                {provider.portfolio.map((item) => (
                  <div key={item.title} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                    <p className="font-semibold text-slate-900">{item.title}</p>
                    <p className="mt-2 text-sm leading-6 text-slate-600">{item.detail}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="rounded-[24px] border border-slate-200 bg-white p-6 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Kanuni za soko</h2>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-600">
              <li>• Mawasiliano ya mteja na mtoa huduma yanasalia ndani ya mfumo.</li>
              <li>• Majadiliano ya bei yanaandikwa kabla ya kuthibitisha agizo.</li>
              <li>• Malipo yanatolewa moja kwa moja nje ya app kati ya mteja na mtoa huduma.</li>
              <li>• Mfumo hufuatilia komisheni ya 5% ya kazi zilizokamilika.</li>
              <li>• Watoa huduma walioidhinishwa lazima wapitishe ukaguzi wa vitambulisho kabla ya kupandishwa hadharani.</li>
            </ul>

            <div className="mt-6 rounded-2xl border border-[#d5e7da] bg-[#f5faf6] p-4 text-sm text-slate-700">
              <p className="font-semibold text-[#0f5132]">Kumbuka usalama</p>
              <p className="mt-2">Maelezo ya NIDA yanabaki kwenye idara ya admin pekee na hayajaonyeshwa hadharani.</p>
            </div>
          </section>
        </div>
    </main>
  );
}
