import type { Metadata, Viewport } from "next";
import Link from "next/link";
import { Geist, Geist_Mono } from "next/font/google";
import AIAssistant from "@/components/ai-assistant";
import CustomerServiceMenu from "@/components/customer-service-menu";
import ServiceWorkerRegistration from "@/components/service-worker-registration";
import "./globals.css";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "HUDUMA LINK",
  description: "Huduma Link ni soko la huduma lililothibitishwa Tanzania. Tafuta fundi au mtaalamu, jadiliane bei ndani ya mfumo, hakiki booking na fuatilia kumbukumbu ya kazi yote.",
  manifest: "/manifest.webmanifest",
  appleWebApp: {
    capable: true,
    statusBarStyle: "black-translucent",
    title: "Huduma Link",
  },
  icons: {
    icon: [
      { url: "/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/apple-icon.png", sizes: "180x180", type: "image/png" }],
  },
};

export const viewport: Viewport = {
  themeColor: "#101c18",
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="sw"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full bg-[#101c18] text-slate-100">
        <div className="min-h-screen bg-[#101c18] pb-16 md:pb-0">
          <header className="mx-auto flex max-w-7xl items-center justify-between border-b border-white/10 bg-[#101c18] px-4 py-[10px] md:px-6">
            <Link href="/" className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#32ad8b] text-lg font-bold text-[#10251e] shadow-sm">
                ✓
              </div>
              <div className="font-serif text-white">
                <p className="text-xl font-semibold">Huduma Link</p>
              </div>
            </Link>

            <div className="flex items-center gap-3">
              <CustomerServiceMenu />
              <button type="button" aria-label="Menyu" className="flex h-11 w-11 items-center justify-center rounded-xl border border-transparent bg-transparent text-2xl text-white transition hover:border-white/15 hover:bg-white/5">
                <span aria-hidden="true">☰</span>
              </button>
            </div>
          </header>

          {children}

          <footer className="mx-auto mt-12 max-w-7xl border-t border-white/10 px-4 pb-12 pt-8 md:px-6">
            <div className="grid gap-8 md:grid-cols-[1.3fr_0.7fr_1fr]">
              <div>
                <p className="font-serif text-2xl font-semibold text-white">Huduma Link</p>
                <p className="mt-3 max-w-md text-sm leading-6 text-slate-300">
                  Jukwaa la kuaminika linalounganisha wateja na watoa huduma waliothibitishwa Tanzania.
                </p>
              </div>

              <div>
                <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-400">Viungo</p>
                <div className="mt-4 space-y-2 text-sm text-slate-300">
                  <Link href="/watoa-huduma" className="block hover:text-white">Tafuta mtoa huduma</Link>
                  <Link href="/install" className="block hover:text-white">Pakua programu</Link>
                  <Link href="/jiunge" className="block hover:text-white">Fungua akaunti</Link>
                  <Link href="/kanuni" className="block hover:text-white">Kanuni na masharti</Link>
                </div>
              </div>

              <div>
                <p className="flex items-center gap-2 text-sm font-semibold text-slate-100">
                  <span className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-emerald-900 text-emerald-300">✓</span>
                  Mawasiliano salama
                </p>
                <p className="mt-3 text-sm leading-6 text-slate-300">
                  Mawasiliano, majadiliano ya bei na booking zote hufanyika ndani ya mfumo. Namba za simu hazionyeshwi hadharani, na taarifa za NIDA huonwa na wasimamizi pekee.
                </p>
                <div className="mt-5 border-t border-white/15 pt-4">
                  <p className="text-sm font-semibold text-slate-100">Huduma kwa wateja</p>
                  <a href="mailto:hudumalink42@gmail.com" className="mt-2 block text-sm text-slate-300 hover:text-white">hudumalink42@gmail.com</a>
                  <a href="tel:0742601351" className="mt-1 block text-sm text-slate-300 hover:text-white">0742601351</a>
                </div>
              </div>
            </div>

            <div className="mt-8 border-t border-white/15 pt-5 text-sm text-slate-400">
              © 2026 Huduma Link. Kamisheni ya jukwaa ni 5% ya huduma iliyokamilika, inayolipwa na mtoa huduma.
            </div>
          </footer>

          <AIAssistant />
          <ServiceWorkerRegistration />

          <nav aria-label="Urambazaji wa chini" className="fixed inset-x-0 bottom-0 z-20 grid grid-cols-3 border-t border-white/15 bg-black/95 px-3 py-2 shadow-[0_-8px_24px_rgba(0,0,0,0.3)] backdrop-blur md:hidden">
            <Link href="/" className="flex flex-col items-center gap-0.5 py-1 text-xs font-medium text-slate-300">
              <span aria-hidden="true" className="text-lg leading-5">⌂</span>
              Nyumbani
            </Link>
            <Link href="/watoa-huduma" className="flex flex-col items-center gap-0.5 py-1 text-xs font-medium text-slate-300">
              <span aria-hidden="true" className="text-lg leading-5">⌕</span>
              Tafuta
            </Link>
            <Link href="/dashboard/customer" className="flex flex-col items-center gap-0.5 py-1 text-xs font-medium text-slate-300">
              <span aria-hidden="true" className="text-lg leading-5">▤</span>
              Dashibodi
            </Link>
          </nav>
        </div>
      </body>
    </html>
  );
}
