import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "Huduma Link",
    short_name: "Huduma Link",
    description: "Soko la huduma lililothibitishwa Tanzania.",
    start_url: "/",
    scope: "/",
    display: "standalone",
    background_color: "#101c18",
    theme_color: "#101c18",
    orientation: "portrait-primary",
    icons: [
      { src: "/icon-192.png", sizes: "192x192", type: "image/png", purpose: "any" },
      { src: "/icon-512.png", sizes: "512x512", type: "image/png", purpose: "maskable" },
    ],
  };
}