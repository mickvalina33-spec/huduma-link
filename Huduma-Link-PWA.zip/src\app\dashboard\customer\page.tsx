import { customerBookings } from "@/data/marketplace";

function formatTzs(value: number) {
  return new Intl.NumberFormat("en-TZ", {
    style: "currency",
    currency: "TZS",
    maximumFractionDigits: 0,
  }).format(value);
}

export default function CustomerDashboardPage() {
  return (
    <main className="mx-auto min-h-[60vh] max-w-6xl px-4 py-8 md:px-6 md:py-12">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Dashibodi ya mteja</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-white">Karibu tena, Amina</h1>
        </div>

        <div className="grid gap-5 md:grid-cols-3">
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Maagizo yanayokuja</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">3</p>
          </div>
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Taarifa</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">7</p>
          </div>
          <div className="rounded-[22px] border border-slate-200 bg-white p-5 shadow-sm">
            <p className="text-sm text-slate-500">Maoni yaliyobaki</p>
            <p className="mt-2 text-3xl font-bold text-slate-900">12</p>
          </div>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
          <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Maagizo ya hivi karibuni</h2>
            <div className="mt-4 space-y-4">
              {customerBookings.map((booking) => (
                <div key={booking.id} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold text-slate-900">{booking.service}</p>
                    <span className="rounded-full bg-[#e8f3ec] px-2 py-1 text-xs font-medium text-[#0f5132]">{booking.status}</span>
                  </div>
                  <p className="mt-2 text-sm text-slate-600">{booking.provider}</p>
                  <p className="mt-2 text-sm font-semibold text-[#0f5132]">{formatTzs(booking.price)}</p>
                </div>
              ))}
            </div>
          </section>

          <section className="rounded-[24px] border border-slate-200 bg-white p-5 shadow-sm">
            <h2 className="text-xl font-semibold text-slate-900">Malipo na maoni</h2>
            <ul className="mt-4 space-y-3 text-sm leading-6 text-slate-600">
              <li>• Malipo ya moja kwa moja nje ya app yanarekodiwa kwa marejeleo ya shughuli.</li>
              <li>• Thibitisha ukamilishaji mara huduma itakapokidhi matarajio.</li>
              <li>• Ripoti matatizo au mizozo kwa hali ya ubora, kughairiwa, au malipo.</li>
              <li>• Acha maoni yaliyo sahihi yanayohusiana na maagizo yaliyokamilika.</li>
            </ul>
          </section>
        </div>
    </main>
  );
}
