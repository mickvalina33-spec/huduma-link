"use client";

import { FormEvent, useState } from "react";

export default function CustomerRegistrationPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="mx-auto max-w-4xl px-4 py-8 md:px-6 md:py-12">
      <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm md:p-8">
        <div className="mb-8">
          <p className="text-xs font-semibold uppercase tracking-[0.24em] text-[#0f5132]">Fungua akaunti / Mteja</p>
          <h1 className="mt-2 text-3xl font-bold tracking-tight text-slate-900">Taarifa zako za mteja</h1>
          <p className="mt-3 text-sm leading-6 text-slate-600">Tumia taarifa hizi kuwasiliana na watoa huduma ndani ya mfumo. Namba yako ya simu haitachapishwa hadharani.</p>
        </div>

        {submitted ? (
          <div className="rounded-2xl border border-[#c7dfcf] bg-[#f3faf5] p-5 text-slate-800">
            <p className="text-lg font-semibold">Usajili umepokelewa.</p>
            <p className="mt-2 text-sm text-slate-600">Akaunti yako ya mteja imewekwa kwenye hatua ya uhakiki. Tutakutumia barua pepe au SMS ukishaithibitishwa.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="grid gap-5 md:grid-cols-2">
            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Jina kamili</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Mfano: Amina Mzava" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Namba ya simu</span>
              <input type="tel" required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="+255 712 345 678" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Barua pepe</span>
              <input type="email" required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="jina@barua.com" />
            </label>

            <label className="space-y-2 md:col-span-1">
              <span className="text-sm font-medium text-slate-700">Mkoa / Wilaya</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Dar es Salaam, Kinondoni" />
            </label>

            <label className="space-y-2 md:col-span-2">
              <span className="text-sm font-medium text-slate-700">Aina ya huduma inayohitajika</span>
              <input required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Umeme, usafi wa nyumba, mabomba, matengenezo ya nyumba..." />
            </label>

            <label className="space-y-2 md:col-span-2">
              <span className="text-sm font-medium text-slate-700">Maelezo ya tatizo / huduma</span>
              <textarea rows={4} required className="w-full rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900 outline-none placeholder:text-slate-400 focus:border-[#0f5132] focus:ring-2 focus:ring-[#0f5132]/10" placeholder="Eleza eneo, kipengele cha huduma, na muda / tarehe unayohitaji huduma." />
            </label>

            <div className="flex flex-col gap-4 border-t border-slate-200 pt-5 md:col-span-2 md:flex-row md:items-center md:justify-between">
              <p className="max-w-md text-xs leading-5 text-slate-500">Taarifa zako huhifadhiwa kwa usiri na hutumika kwa madhumuni ya huduma pekee.</p>
              <button type="submit" className="rounded-full bg-[#0f5132] px-5 py-3 text-sm font-semibold text-white transition hover:bg-[#0b3d27]">
                Wasilisha usajili
              </button>
            </div>
          </form>
        )}
      </div>
    </main>
  );
}
