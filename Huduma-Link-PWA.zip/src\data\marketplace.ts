export type Category = {
  name: string;
  count: string;
  accent: string;
};

export type Provider = {
  id: string;
  name: string;
  category: string;
  location: string;
  serviceArea: string;
  rating: number;
  reviews: number;
  delivered: number;
  priceFrom: number;
  verification: "Imethibitishwa" | "Inasubiri" | "Maelezo Ya Ziada" | "Imekataliwa";
  description: string;
  availability: string;
  experience: string;
  specialties: string[];
  portfolio: { title: string; detail: string }[];
};

export const categories: Category[] = [
  { name: "Ujenzi wa Nyumba", count: "184 wa kutosha", accent: "from-amber-500 to-orange-500" },
  { name: "Umeme", count: "127 wa kutosha", accent: "from-cyan-500 to-sky-500" },
  { name: "Usafi", count: "96 wa kutosha", accent: "from-emerald-500 to-teal-500" },
  { name: "Mifumo ya Majitaka", count: "83 wa kutosha", accent: "from-indigo-500 to-violet-500" },
  { name: "Teknolojia na Dijitali", count: "74 wa kutosha", accent: "from-fuchsia-500 to-pink-500" },
  { name: "Huduma za Mifumo", count: "59 wa kutosha", accent: "from-rose-500 to-red-500" },
];

export const stats = [
  { label: "Watoa huduma waliothibitishwa", value: "2,460" },
  { label: "Maagizo mwezi huu", value: "7,890" },
  { label: "Kutosheleza kwa wateja", value: "4.9/5" },
  { label: "Tume ya komisheni", value: "TZS 148M" },
];

export const providers: Provider[] = [];

export const customerBookings = [
  { id: "BK-1024", service: "Kurekebisha nyaya za jikoni", provider: "Mtoa huduma wa umeme aliyeandikishwa", status: "Imethibitishwa", price: 95000 },
  { id: "BK-1081", service: "Usafi wa ofisi", provider: "Mtoa huduma wa usafi aliyeandikishwa", status: "Huduma Imeanza", price: 74000 },
  { id: "BK-1127", service: "Kurekebisha bomba la bafu", provider: "Mtoa huduma wa mifumo ya maji", status: "Majadiliano ya Bei", price: 68000 },
];

export const providerTransactions = [
  { id: "TX-204", booking: "BK-1024", value: 95000, commissionGenerated: 4750, commissionPaid: 0, outstanding: 4750 },
  { id: "TX-189", booking: "BK-876", value: 128000, commissionGenerated: 6400, commissionPaid: 6400, outstanding: 0 },
  { id: "TX-162", booking: "BK-733", value: 87000, commissionGenerated: 4350, commissionPaid: 2200, outstanding: 2150 },
];

export const adminOverview = [
  { label: "Akaunti amilifu", value: "8,421" },
  { label: "Uthibitishaji unaosubiri", value: "146" },
  { label: "Mizozo inayoendelea", value: "23" },
  { label: "Komisheni inayosubiri", value: "TZS 61.4M" },
];

export const messageThreads = [
  { id: "msg-1", participant: "Mtoa huduma wa umeme", preview: "Kiasi cha kazi kimewekwa tayari na ni pamoja na ukaguzi wa nyaya.", time: "dakika 2 zilizopita" },
  { id: "msg-2", participant: "Mtoa huduma wa usafi", preview: "Tunaweza kupanga usafi Jumamosi asubuhi.", time: "dakika 14 zilizopita" },
  { id: "msg-3", participant: "Mtoa huduma wa mifumo ya maji", preview: "Tunahitaji kufikia sehemu ya bomba kabla ya saa 11 asubuhi.", time: "saa 1 iliyopita" },
];
